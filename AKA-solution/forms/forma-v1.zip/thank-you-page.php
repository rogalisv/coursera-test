<? $status = $_GET['status']; ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Создание формы обратной связи</title>
<!-- <meta http-equiv="Refresh" content="4; URL=http://katalogsemyan.ru">   -->
</head>
<body>
<?=$status?>
<p>Страница благодарности</p>

</body>
</html>